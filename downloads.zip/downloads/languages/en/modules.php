<?php 

$GLOBALS['TL_LANG']['MOD']['downloads'][0] = 'downloads';
$GLOBALS['TL_LANG']['MOD']['downloads'][1] = 'adding and editing downlaod-files';

$GLOBALS['TL_LANG']['FMD']['download_foehn_alle'] = 'Foehn Liste';
$GLOBALS['TL_LANG']['FMD']['download_foehn_newest'] = 'Neuster Foehn';


?>