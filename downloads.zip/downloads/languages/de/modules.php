<?php 

$GLOBALS['TL_LANG']['MOD']['downloads'][0] = 'Downloads';
$GLOBALS['TL_LANG']['MOD']['downloads'][1] = 'Downloads einf&uuml;gen und verwalten';

$GLOBALS['TL_LANG']['FMD']['download_foehn_alle'] = 'Foehn Liste';
$GLOBALS['TL_LANG']['FMD']['download_foehn_newest'] = 'Neuster Foehn';


?>