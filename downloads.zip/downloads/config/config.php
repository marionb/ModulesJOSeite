<?php 

$GLOBALS['BE_MOD']['content']['downloads'] = array(
    'tables' => array('tl_downloads'), 
    'icon' => 'system/themes/default/images/article.gif'
);


$GLOBALS['FE_MOD']['downloads'] = array
(
	'download_foehn_alle'     => 'ModuleFoehnAlle',
	'download_foehn_newest'	  => 'ModuleFoehnNewest'
);
?>