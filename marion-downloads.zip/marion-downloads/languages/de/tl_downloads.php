<?php

$GLOBALS['TL_LANG']['tl_downloads']['new'][0] = 'Neuer Download';
$GLOBALS['TL_LANG']['tl_downloads']['new'][1] = 'Neuer Download anlegen';
$GLOBALS['TL_LANG']['tl_downloads']['edit'][0] = 'Download bearbeiten';
$GLOBALS['TL_LANG']['tl_downloads']['edit'][1] = 'Vorhandener Download bearbeiten';
$GLOBALS['TL_LANG']['tl_downloads']['show'][0] = 'Details';
$GLOBALS['TL_LANG']['tl_downloads']['show'][1] = 'Details des Downloads anzeigen';
$GLOBALS['TL_LANG']['tl_downloads']['delete'][0] = 'Download entfernen';
$GLOBALS['TL_LANG']['tl_downloads']['delete'][1] = 'Download entfernen';

$GLOBALS['TL_LANG']['tl_downloads']['title_legend']= 'Titel';
$GLOBALS['TL_LANG']['tl_downloads']['download_legend']= 'Genaue Angaben';
$GLOBALS['TL_LANG']['tl_downloads']['title']['0'] = 'Download Titel';
$GLOBALS['TL_LANG']['tl_downloads']['title']['1'] = 'Gebe einen Titel f&uuml;r den Download';
$GLOBALS['TL_LANG']['tl_downloads']['description']['0'] = 'Beschreibung des Downloads';
$GLOBALS['TL_LANG']['tl_downloads']['description']['1'] = 'Kurtz Beschreibung f&uuml;r den Download';
$GLOBALS['TL_LANG']['tl_downloads']['href']['0'] = 'Link';
$GLOBALS['TL_LANG']['tl_downloads']['href']['1'] = 'W&auml;hle die Datei f&uuml;r den Download';
$GLOBALS['TL_LANG']['tl_downloads']['sort_order']['0'] = 'Reihenfolge (Zahl)';
$GLOBALS['TL_LANG']['tl_downloads']['sort_order']['1'] = 'Die h&ouml;he der eingetragenen Zahl beeinflusst die Reihenfolge der Download-Auflistung';
$GLOBALS['TL_LANG']['tl_downloads']['type']['0'] = 'Downloadkategorie';
$GLOBALS['TL_LANG']['tl_downloads']['type']['1'] = 'Die Kategorie besimmt wo der Download erscheint';

?>