<?php
/**
 * Definition eines Frontend Moduls
*/
array_insert($GLOBALS['FE_MOD']['miscellaneous'], 0, array
		(
				'tiles' => 'ModuleTile'
		));
		
$GLOBALS['TL_CONFIG']['displayErrors'] = true;
		
?>